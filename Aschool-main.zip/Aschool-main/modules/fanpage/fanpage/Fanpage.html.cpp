<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <title>Disney Records</title>
    <link rel="Disney Music" href="https://www.disneymusicemporium.com/">
    <a href="https://music.amazon.com/search/disney?filter=IsLibrary%7Cfalse&sc=none">Sounds of Disney</a>
    </head>
    <body>
    <p><h1>WELCOME TO DISNEY MUSIC EMPORIUM!</h1>
<h2>Disney Music Emporium is THE online destination for all things collectible and limited edition from the legendary Disney Music catalog.
Disney Music Emporium's (DME) goal is not only to create a marketplace where our fans can access unique and collectible music products, but to also create a space where we can engage together in a dynamic and exciting way. DME is Disney Music Group's "Field of Dreams," a destination to showcase unique and collectible Disney music products. We have a rich catalog of music that continues to grow year after year and our genuine hope is that DME becomes a favorite spot for you to interact with our catalog and join us in conversation.
We want your input! We value your expertise and enthusiasm to help ensure our great catalog of music is always accessible for all to enjoy. If you have a great idea of a product you would like to see, we would love to hear from you. Please contact us at DMGDMEfeedback@disney.com. We will do our best to respond in a timely manner. For immediate customer service or order issues please see the “Questions or Concerns" section below.
We look forward to hearing from you!
Sincerely,
The Disney Music Emporium Team </h2></p>
    </body>

